from distutils.core import setup

setup(
    name='redorblue',
    version='0.1dev',
    packages=['redorblue',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)